package binarySearchTreeIterator;

/**
 * Created by leicao on 5/10/15.
 */
public class TreeNode {
    public int val;
    public TreeNode left, right;
    public TreeNode(int val) {
        this.val = val;
        this.left = this.right = null;
    }
}
